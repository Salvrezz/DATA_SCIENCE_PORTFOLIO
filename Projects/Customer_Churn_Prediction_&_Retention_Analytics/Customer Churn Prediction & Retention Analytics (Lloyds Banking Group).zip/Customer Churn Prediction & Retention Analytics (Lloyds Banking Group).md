```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import shap
from sklearn.preprocessing import OneHotEncoder, StandardScaler, OrdinalEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import (
    accuracy_score,
    make_scorer,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    classification_report,
    ConfusionMatrixDisplay
)
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import GradientBoostingClassifier
from xgboost import XGBClassifier
from sklearn.svm import SVC

%matplotlib inline
```


```python
df = pd.read_excel(r"C:\Users\GWX-DATA\Videos\Captures\BANK\Lloyds.xlsx")
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>InteractionID</th>
      <th>InteractionDate</th>
      <th>InteractionType</th>
      <th>ResolutionStatus</th>
      <th>TransactionID</th>
      <th>TransactionDate</th>
      <th>AmountSpent</th>
      <th>ProductCategory</th>
      <th>Age</th>
      <th>AgeBracket</th>
      <th>Gender</th>
      <th>MaritalStatus</th>
      <th>IncomeLevel</th>
      <th>LastLoginDate</th>
      <th>LoginFrequency</th>
      <th>ServiceUsage</th>
      <th>ChurnStatus</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>6363.0</td>
      <td>2022-03-31</td>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>7194</td>
      <td>2022-03-27</td>
      <td>416.50</td>
      <td>Electronics</td>
      <td>62</td>
      <td>Elder</td>
      <td>M</td>
      <td>Single</td>
      <td>Low</td>
      <td>2023-10-21</td>
      <td>34</td>
      <td>Mobile App</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>3329.0</td>
      <td>2022-03-17</td>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>7250</td>
      <td>2022-08-08</td>
      <td>54.96</td>
      <td>Clothing</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>2023-12-05</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>3329.0</td>
      <td>2022-03-17</td>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>9660</td>
      <td>2022-07-25</td>
      <td>197.50</td>
      <td>Electronics</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>2023-12-05</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>3329.0</td>
      <td>2022-03-17</td>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>2998</td>
      <td>2022-01-25</td>
      <td>101.31</td>
      <td>Furniture</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>2023-12-05</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>3329.0</td>
      <td>2022-03-17</td>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>1228</td>
      <td>2022-07-24</td>
      <td>397.37</td>
      <td>Clothing</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>2023-12-05</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>6807</th>
      <td>1000</td>
      <td>NaN</td>
      <td>NaT</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2724</td>
      <td>2022-09-08</td>
      <td>232.06</td>
      <td>Groceries</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>2023-08-13</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6808</th>
      <td>1000</td>
      <td>NaN</td>
      <td>NaT</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2917</td>
      <td>2022-12-13</td>
      <td>324.98</td>
      <td>Books</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>2023-08-13</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6809</th>
      <td>1000</td>
      <td>NaN</td>
      <td>NaT</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2979</td>
      <td>2022-06-15</td>
      <td>375.34</td>
      <td>Groceries</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>2023-08-13</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6810</th>
      <td>1000</td>
      <td>NaN</td>
      <td>NaT</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8594</td>
      <td>2022-04-08</td>
      <td>166.73</td>
      <td>Books</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>2023-08-13</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6811</th>
      <td>1000</td>
      <td>NaN</td>
      <td>NaT</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5529</td>
      <td>2022-11-23</td>
      <td>93.73</td>
      <td>Furniture</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>2023-08-13</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>6812 rows × 18 columns</p>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 6812 entries, 0 to 6811
    Data columns (total 18 columns):
     #   Column            Non-Null Count  Dtype         
    ---  ------            --------------  -----         
     0   CustomerID        6812 non-null   int64         
     1   InteractionID     5204 non-null   float64       
     2   InteractionDate   5204 non-null   datetime64[ns]
     3   InteractionType   5204 non-null   object        
     4   ResolutionStatus  5204 non-null   object        
     5   TransactionID     6812 non-null   int64         
     6   TransactionDate   6812 non-null   datetime64[ns]
     7   AmountSpent       6812 non-null   float64       
     8   ProductCategory   6812 non-null   object        
     9   Age               6812 non-null   int64         
     10  AgeBracket        6812 non-null   object        
     11  Gender            6812 non-null   object        
     12  MaritalStatus     6812 non-null   object        
     13  IncomeLevel       6812 non-null   object        
     14  LastLoginDate     6812 non-null   datetime64[ns]
     15  LoginFrequency    6812 non-null   int64         
     16  ServiceUsage      6812 non-null   object        
     17  ChurnStatus       6812 non-null   int64         
    dtypes: datetime64[ns](3), float64(2), int64(5), object(8)
    memory usage: 958.1+ KB
    


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>InteractionID</th>
      <th>InteractionDate</th>
      <th>TransactionID</th>
      <th>TransactionDate</th>
      <th>AmountSpent</th>
      <th>Age</th>
      <th>LastLoginDate</th>
      <th>LoginFrequency</th>
      <th>ChurnStatus</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>6812.000000</td>
      <td>5204.000000</td>
      <td>5204</td>
      <td>6812.000000</td>
      <td>6812</td>
      <td>6812.000000</td>
      <td>6812.000000</td>
      <td>6812</td>
      <td>6812.000000</td>
      <td>6812.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>500.169260</td>
      <td>5921.861261</td>
      <td>2022-07-01 16:31:10.561106944</td>
      <td>5497.323253</td>
      <td>2022-07-01 02:11:29.136817408</td>
      <td>251.620527</td>
      <td>43.274516</td>
      <td>2023-07-06 04:56:47.633587712</td>
      <td>25.724310</td>
      <td>0.198473</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>2015.000000</td>
      <td>2022-01-01 00:00:00</td>
      <td>1000.000000</td>
      <td>2022-01-01 00:00:00</td>
      <td>5.180000</td>
      <td>18.000000</td>
      <td>2023-01-01 00:00:00</td>
      <td>1.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>247.000000</td>
      <td>3873.250000</td>
      <td>2022-04-07 00:00:00</td>
      <td>3223.500000</td>
      <td>2022-04-02 00:00:00</td>
      <td>127.100000</td>
      <td>30.000000</td>
      <td>2023-04-12 00:00:00</td>
      <td>14.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>505.500000</td>
      <td>5903.000000</td>
      <td>2022-07-02 00:00:00</td>
      <td>5515.000000</td>
      <td>2022-07-01 00:00:00</td>
      <td>251.845000</td>
      <td>44.000000</td>
      <td>2023-07-13 00:00:00</td>
      <td>26.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>750.000000</td>
      <td>7851.000000</td>
      <td>2022-09-25 00:00:00</td>
      <td>7675.250000</td>
      <td>2022-09-30 00:00:00</td>
      <td>375.280000</td>
      <td>56.000000</td>
      <td>2023-10-01 00:00:00</td>
      <td>38.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1000.000000</td>
      <td>9997.000000</td>
      <td>2022-12-30 00:00:00</td>
      <td>9997.000000</td>
      <td>2022-12-31 00:00:00</td>
      <td>499.860000</td>
      <td>69.000000</td>
      <td>2023-12-31 00:00:00</td>
      <td>49.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>286.704642</td>
      <td>2332.331260</td>
      <td>NaN</td>
      <td>2584.768541</td>
      <td>NaN</td>
      <td>142.901693</td>
      <td>15.286788</td>
      <td>NaN</td>
      <td>14.062032</td>
      <td>0.398880</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.isna().sum().sort_values(ascending=False)
```




    InteractionID       1608
    InteractionDate     1608
    ResolutionStatus    1608
    InteractionType     1608
    CustomerID             0
    TransactionID          0
    TransactionDate        0
    AmountSpent            0
    ProductCategory        0
    Age                    0
    AgeBracket             0
    Gender                 0
    MaritalStatus          0
    IncomeLevel            0
    LastLoginDate          0
    LoginFrequency         0
    ServiceUsage           0
    ChurnStatus            0
    dtype: int64




```python
#Drrop unnecessary columns
drop_cols = [
    "CustomerID",
    "InteractionID",
    "TransactionID",
    "InteractionDate",
    "TransactionDate"
]

df.drop(columns=drop_cols, inplace=True, errors="ignore")
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InteractionType</th>
      <th>ResolutionStatus</th>
      <th>AmountSpent</th>
      <th>ProductCategory</th>
      <th>Age</th>
      <th>AgeBracket</th>
      <th>Gender</th>
      <th>MaritalStatus</th>
      <th>IncomeLevel</th>
      <th>LastLoginDate</th>
      <th>LoginFrequency</th>
      <th>ServiceUsage</th>
      <th>ChurnStatus</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>416.50</td>
      <td>Electronics</td>
      <td>62</td>
      <td>Elder</td>
      <td>M</td>
      <td>Single</td>
      <td>Low</td>
      <td>2023-10-21</td>
      <td>34</td>
      <td>Mobile App</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>54.96</td>
      <td>Clothing</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>2023-12-05</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>197.50</td>
      <td>Electronics</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>2023-12-05</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>101.31</td>
      <td>Furniture</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>2023-12-05</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>397.37</td>
      <td>Clothing</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>2023-12-05</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>6807</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>232.06</td>
      <td>Groceries</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>2023-08-13</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6808</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>324.98</td>
      <td>Books</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>2023-08-13</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6809</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>375.34</td>
      <td>Groceries</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>2023-08-13</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6810</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>166.73</td>
      <td>Books</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>2023-08-13</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6811</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>93.73</td>
      <td>Furniture</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>2023-08-13</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>6812 rows × 13 columns</p>
</div>




```python
#Coverting last_login_Date to Days_Since_Last_Login 
df["LastLoginDate"] = pd.to_datetime(df["LastLoginDate"], errors="coerce")

reference_date = df["LastLoginDate"].max()

df["DaysSinceLastLogin"] = (reference_date - df["LastLoginDate"]).dt.days

df = df.drop(columns=["LastLoginDate"])
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InteractionType</th>
      <th>ResolutionStatus</th>
      <th>AmountSpent</th>
      <th>ProductCategory</th>
      <th>Age</th>
      <th>AgeBracket</th>
      <th>Gender</th>
      <th>MaritalStatus</th>
      <th>IncomeLevel</th>
      <th>LoginFrequency</th>
      <th>ServiceUsage</th>
      <th>ChurnStatus</th>
      <th>DaysSinceLastLogin</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>416.50</td>
      <td>Electronics</td>
      <td>62</td>
      <td>Elder</td>
      <td>M</td>
      <td>Single</td>
      <td>Low</td>
      <td>34</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>71</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>54.96</td>
      <td>Clothing</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
      <td>26</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>197.50</td>
      <td>Electronics</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
      <td>26</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>101.31</td>
      <td>Furniture</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
      <td>26</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>397.37</td>
      <td>Clothing</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
      <td>26</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>6807</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>232.06</td>
      <td>Groceries</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>140</td>
    </tr>
    <tr>
      <th>6808</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>324.98</td>
      <td>Books</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>140</td>
    </tr>
    <tr>
      <th>6809</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>375.34</td>
      <td>Groceries</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>140</td>
    </tr>
    <tr>
      <th>6810</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>166.73</td>
      <td>Books</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>140</td>
    </tr>
    <tr>
      <th>6811</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>93.73</td>
      <td>Furniture</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>140</td>
    </tr>
  </tbody>
</table>
<p>6812 rows × 13 columns</p>
</div>




```python
# example: df already loaded
df[["InteractionType", "ResolutionStatus"]] = (
    df[["InteractionType", "ResolutionStatus"]].replace(np.nan, "")
)
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InteractionType</th>
      <th>ResolutionStatus</th>
      <th>AmountSpent</th>
      <th>ProductCategory</th>
      <th>Age</th>
      <th>AgeBracket</th>
      <th>Gender</th>
      <th>MaritalStatus</th>
      <th>IncomeLevel</th>
      <th>LoginFrequency</th>
      <th>ServiceUsage</th>
      <th>ChurnStatus</th>
      <th>DaysSinceLastLogin</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>416.50</td>
      <td>Electronics</td>
      <td>62</td>
      <td>Elder</td>
      <td>M</td>
      <td>Single</td>
      <td>Low</td>
      <td>34</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>71</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>54.96</td>
      <td>Clothing</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
      <td>26</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>197.50</td>
      <td>Electronics</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
      <td>26</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>101.31</td>
      <td>Furniture</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
      <td>26</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>397.37</td>
      <td>Clothing</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
      <td>26</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>6807</th>
      <td></td>
      <td></td>
      <td>232.06</td>
      <td>Groceries</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>140</td>
    </tr>
    <tr>
      <th>6808</th>
      <td></td>
      <td></td>
      <td>324.98</td>
      <td>Books</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>140</td>
    </tr>
    <tr>
      <th>6809</th>
      <td></td>
      <td></td>
      <td>375.34</td>
      <td>Groceries</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>140</td>
    </tr>
    <tr>
      <th>6810</th>
      <td></td>
      <td></td>
      <td>166.73</td>
      <td>Books</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>140</td>
    </tr>
    <tr>
      <th>6811</th>
      <td></td>
      <td></td>
      <td>93.73</td>
      <td>Furniture</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>140</td>
    </tr>
  </tbody>
</table>
<p>6812 rows × 13 columns</p>
</div>




```python
df[["InteractionType", "ResolutionStatus"]] = (
    df[["InteractionType", "ResolutionStatus"]]
    .replace("", "Unknown")
    .fillna("Unknown")
)

```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InteractionType</th>
      <th>ResolutionStatus</th>
      <th>AmountSpent</th>
      <th>ProductCategory</th>
      <th>Age</th>
      <th>AgeBracket</th>
      <th>Gender</th>
      <th>MaritalStatus</th>
      <th>IncomeLevel</th>
      <th>LoginFrequency</th>
      <th>ServiceUsage</th>
      <th>ChurnStatus</th>
      <th>DaysSinceLastLogin</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>416.50</td>
      <td>Electronics</td>
      <td>62</td>
      <td>Elder</td>
      <td>M</td>
      <td>Single</td>
      <td>Low</td>
      <td>34</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>71</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>54.96</td>
      <td>Clothing</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
      <td>26</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>197.50</td>
      <td>Electronics</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
      <td>26</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>101.31</td>
      <td>Furniture</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
      <td>26</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>397.37</td>
      <td>Clothing</td>
      <td>65</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>5</td>
      <td>Website</td>
      <td>1</td>
      <td>26</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>6807</th>
      <td>Unknown</td>
      <td>Unknown</td>
      <td>232.06</td>
      <td>Groceries</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>140</td>
    </tr>
    <tr>
      <th>6808</th>
      <td>Unknown</td>
      <td>Unknown</td>
      <td>324.98</td>
      <td>Books</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>140</td>
    </tr>
    <tr>
      <th>6809</th>
      <td>Unknown</td>
      <td>Unknown</td>
      <td>375.34</td>
      <td>Groceries</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>140</td>
    </tr>
    <tr>
      <th>6810</th>
      <td>Unknown</td>
      <td>Unknown</td>
      <td>166.73</td>
      <td>Books</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>140</td>
    </tr>
    <tr>
      <th>6811</th>
      <td>Unknown</td>
      <td>Unknown</td>
      <td>93.73</td>
      <td>Furniture</td>
      <td>34</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22</td>
      <td>Mobile App</td>
      <td>0</td>
      <td>140</td>
    </tr>
  </tbody>
</table>
<p>6812 rows × 13 columns</p>
</div>




```python
df.isna().sum().sort_values(ascending=False)
```




    InteractionType       0
    ResolutionStatus      0
    AmountSpent           0
    ProductCategory       0
    Age                   0
    AgeBracket            0
    Gender                0
    MaritalStatus         0
    IncomeLevel           0
    LoginFrequency        0
    ServiceUsage          0
    ChurnStatus           0
    DaysSinceLastLogin    0
    dtype: int64




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 6812 entries, 0 to 6811
    Data columns (total 13 columns):
     #   Column              Non-Null Count  Dtype  
    ---  ------              --------------  -----  
     0   InteractionType     6812 non-null   object 
     1   ResolutionStatus    6812 non-null   object 
     2   AmountSpent         6812 non-null   float64
     3   ProductCategory     6812 non-null   object 
     4   Age                 6812 non-null   int64  
     5   AgeBracket          6812 non-null   object 
     6   Gender              6812 non-null   object 
     7   MaritalStatus       6812 non-null   object 
     8   IncomeLevel         6812 non-null   object 
     9   LoginFrequency      6812 non-null   int64  
     10  ServiceUsage        6812 non-null   object 
     11  ChurnStatus         6812 non-null   int64  
     12  DaysSinceLastLogin  6812 non-null   int64  
    dtypes: float64(1), int64(4), object(8)
    memory usage: 692.0+ KB
    


```python
#Convert int to float
int_cols = df.select_dtypes(include="int64").columns

df[int_cols] = df[int_cols].astype("float64")

print(df.dtypes)
```

    InteractionType        object
    ResolutionStatus       object
    AmountSpent           float64
    ProductCategory        object
    Age                   float64
    AgeBracket             object
    Gender                 object
    MaritalStatus          object
    IncomeLevel            object
    LoginFrequency        float64
    ServiceUsage           object
    ChurnStatus           float64
    DaysSinceLastLogin    float64
    dtype: object
    


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InteractionType</th>
      <th>ResolutionStatus</th>
      <th>AmountSpent</th>
      <th>ProductCategory</th>
      <th>Age</th>
      <th>AgeBracket</th>
      <th>Gender</th>
      <th>MaritalStatus</th>
      <th>IncomeLevel</th>
      <th>LoginFrequency</th>
      <th>ServiceUsage</th>
      <th>ChurnStatus</th>
      <th>DaysSinceLastLogin</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>416.50</td>
      <td>Electronics</td>
      <td>62.0</td>
      <td>Elder</td>
      <td>M</td>
      <td>Single</td>
      <td>Low</td>
      <td>34.0</td>
      <td>Mobile App</td>
      <td>0.0</td>
      <td>71.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>54.96</td>
      <td>Clothing</td>
      <td>65.0</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>5.0</td>
      <td>Website</td>
      <td>1.0</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>197.50</td>
      <td>Electronics</td>
      <td>65.0</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>5.0</td>
      <td>Website</td>
      <td>1.0</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>101.31</td>
      <td>Furniture</td>
      <td>65.0</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>5.0</td>
      <td>Website</td>
      <td>1.0</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Inquiry</td>
      <td>Resolved</td>
      <td>397.37</td>
      <td>Clothing</td>
      <td>65.0</td>
      <td>Elder</td>
      <td>M</td>
      <td>Married</td>
      <td>Low</td>
      <td>5.0</td>
      <td>Website</td>
      <td>1.0</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>6807</th>
      <td>Unknown</td>
      <td>Unknown</td>
      <td>232.06</td>
      <td>Groceries</td>
      <td>34.0</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22.0</td>
      <td>Mobile App</td>
      <td>0.0</td>
      <td>140.0</td>
    </tr>
    <tr>
      <th>6808</th>
      <td>Unknown</td>
      <td>Unknown</td>
      <td>324.98</td>
      <td>Books</td>
      <td>34.0</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22.0</td>
      <td>Mobile App</td>
      <td>0.0</td>
      <td>140.0</td>
    </tr>
    <tr>
      <th>6809</th>
      <td>Unknown</td>
      <td>Unknown</td>
      <td>375.34</td>
      <td>Groceries</td>
      <td>34.0</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22.0</td>
      <td>Mobile App</td>
      <td>0.0</td>
      <td>140.0</td>
    </tr>
    <tr>
      <th>6810</th>
      <td>Unknown</td>
      <td>Unknown</td>
      <td>166.73</td>
      <td>Books</td>
      <td>34.0</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22.0</td>
      <td>Mobile App</td>
      <td>0.0</td>
      <td>140.0</td>
    </tr>
    <tr>
      <th>6811</th>
      <td>Unknown</td>
      <td>Unknown</td>
      <td>93.73</td>
      <td>Furniture</td>
      <td>34.0</td>
      <td>Adult</td>
      <td>M</td>
      <td>Widowed</td>
      <td>Low</td>
      <td>22.0</td>
      <td>Mobile App</td>
      <td>0.0</td>
      <td>140.0</td>
    </tr>
  </tbody>
</table>
<p>6812 rows × 13 columns</p>
</div>




```python
df["ChurnStatus"].value_counts(normalize=True)
```




    ChurnStatus
    0.0    0.801527
    1.0    0.198473
    Name: proportion, dtype: float64




```python
df.corr(numeric_only=True)["ChurnStatus"].sort_values(ascending=False)
```




    ChurnStatus           1.000000
    Age                   0.045048
    DaysSinceLastLogin    0.031073
    AmountSpent           0.005113
    LoginFrequency       -0.100391
    Name: ChurnStatus, dtype: float64




```python
sns.countplot(x="ChurnStatus", data=df)
plt.title("Churn Distribution")
plt.show()
```


    
![png](output_18_0.png)
    



```python

num_cols = [
    "Age",
    "AmountSpent",
    "LoginFrequency"
]

cat_cols = [
    "Gender",
    "MaritalStatus",
    "IncomeLevel",
    "ProductCategory",
    "InteractionType",
    "ResolutionStatus",
    "AgeBracket",
    "ServiceUsage"
]
```


```python
for col in num_cols:
    sns.boxplot(x="ChurnStatus", y=col, data=df)
    plt.title(f"{col} vs Churn")
    plt.show()

```


    
![png](output_20_0.png)
    



    
![png](output_20_1.png)
    



    
![png](output_20_2.png)
    



```python

```


```python
for col in num_cols:
    sns.histplot(df[col], kde=True)
    plt.title(f"Distribution of {col}")
    plt.show()
```


    
![png](output_22_0.png)
    



    
![png](output_22_1.png)
    



    
![png](output_22_2.png)
    



```python
#Plot cat_cols against churn_rate
for col in cat_cols:
    churn_rate = (
        df.groupby(col)["ChurnStatus"]
        .mean()
        .sort_values(ascending=False)
    )
    churn_rate.plot(kind="bar")
    plt.title(f"Churn Rate by {col}")
    plt.ylabel("Churn Rate")
    plt.show()
```


    
![png](output_23_0.png)
    



    
![png](output_23_1.png)
    



    
![png](output_23_2.png)
    



    
![png](output_23_3.png)
    



    
![png](output_23_4.png)
    



    
![png](output_23_5.png)
    



    
![png](output_23_6.png)
    



    
![png](output_23_7.png)
    



```python
#Plot scatterplot with dayssincelastlogin against loginfrequency, hue=Chrunstatus
sns.scatterplot(
    data=df,
    x="DaysSinceLastLogin",
    y="LoginFrequency",
    hue="ChurnStatus",
    alpha=0.7
)
plt.title("Login Habit vs Recency")
plt.show()
```


    
![png](output_24_0.png)
    



```python

```


```python
# Load data n define target
X = df.drop("ChurnStatus", axis=1)   # change if needed
y = df["ChurnStatus"]
```


```python
# Train-test split (stratified)
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

```


```python
# Identify numerical and categorical features
numeric_features = X.select_dtypes(include=["int64", "float64"]).columns
categorical_features = X.select_dtypes(include=["object", "category"]).columns

```


```python
# Build preprocessing pipeline
numeric_transformer = Pipeline(steps=[
    ("scaler", StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ("onehot", OneHotEncoder(handle_unknown="ignore"))
])

preprocessor = ColumnTransformer(
    transformers=[
        ("num", numeric_transformer, numeric_features),
        ("cat", categorical_transformer, categorical_features)
    ]
)

```


```python
# Handle class imbalance, compute imbalance ratio for XGBoost
neg, pos = y.value_counts()
scale_pos_weight = neg / pos

```


```python
# Define models (with imbalance handling)

from sklearn.svm import SVC
models = {
    "Logistic Regression": LogisticRegression(
        max_iter=1000,
        class_weight="balanced"
    ),

    "Random Forest": RandomForestClassifier(
        random_state=42,
        class_weight="balanced"
    ),

    "Gradient Boosting": GradientBoostingClassifier(
        random_state=42
    ),

    "SVM": SVC(
        probability=True,
        class_weight="balanced"
    ),

    "XGBoost": XGBClassifier(
        objective="binary:logistic",
        eval_metric="logloss",
        random_state=42,
        scale_pos_weight=scale_pos_weight
    )
}

```


```python
# Pipeline 
pipelines = {
    name: Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("model", model)
    ])
    for name, model in models.items()
}

```


```python
# Define GridSearch parameters
param_grids = {
    "Logistic Regression": {
        "model__C": [0.01, 0.1, 1, 10]
    },

    "Random Forest": {
        "model__n_estimators": [100, 200],
        "model__max_depth": [None, 10, 20]
    },

    "Gradient Boosting": {
        "model__n_estimators": [100, 200],
        "model__learning_rate": [0.05, 0.1]
    },

    "SVM": {
        "model__C": [0.1, 1],
        "model__kernel": ["rbf"]
    },

    "XGBoost": {
        "model__n_estimators": [100, 200],
        "model__max_depth": [3, 5],
        "model__learning_rate": [0.05, 0.1],
        "model__subsample": [0.8, 1.0]
    }
}

```


```python
#Train, tune, and compare models
results = {}
best_estimators = {}

for name, pipeline in pipelines.items():
    print(f"Training {name}...")

    grid = GridSearchCV(
        pipeline,
        param_grids[name],
        cv=5,
        scoring="roc_auc",
        n_jobs=-1
    )

    grid.fit(X_train, y_train)

    best_estimators[name] = grid.best_estimator_

    y_prob = grid.best_estimator_.predict_proba(X_test)[:, 1]
    y_pred = (y_prob >= 0.5).astype(int)

    results[name] = {
        "ROC_AUC": roc_auc_score(y_test, y_prob),
        "Accuracy": accuracy_score(y_test, y_pred),
        "F1": f1_score(y_test, y_pred)
    }

```

    Training Logistic Regression...
    Training Random Forest...
    Training Gradient Boosting...
    Training SVM...
    Training XGBoost...
    


```python

```


```python
# selecting best model (by ROC-AUC)
results_df = pd.DataFrame(results).T
results_df = results_df.sort_values(by="ROC_AUC", ascending=False)

print(results_df)

```

                          ROC_AUC  Accuracy        F1
    Random Forest        0.998674  0.982392  0.954023
    XGBoost              0.995729  0.980924  0.951852
    Gradient Boosting    0.939929  0.885547  0.606061
    SVM                  0.909868  0.895084  0.715706
    Logistic Regression  0.586645  0.570800  0.325260
    


```python
best_model_name = results_df.index[0]
best_model = best_estimators[best_model_name]

print("Best model:", best_model_name)

```

    Best model: Random Forest
    


```python
# Select the best Random Forest model from GridSearch
best_rf = best_estimators["Random Forest"]


```


```python
# Generate Predictions & Probabilities 
# Class predictions (0 or 1)
y_pred = best_rf.predict(X_test)

# Predicted probabilities (needed for ROC & thresholding)
y_proba = best_rf.predict_proba(X_test)[:, 1]

```


```python

```


```python

cm = confusion_matrix(y_test, y_pred)

disp = ConfusionMatrixDisplay(
    confusion_matrix=cm,
    display_labels=["Stayed", "Churned"]
)

disp.plot()
plt.title("Confusion Matrix – Random Forest Churn Model")
plt.show()
```


    
![png](output_41_0.png)
    



```python
print("Random Forest – Classification Report")
print(classification_report(y_test, y_pred))
```

    Random Forest – Classification Report
                  precision    recall  f1-score   support
    
             0.0       0.98      1.00      0.99      1092
             1.0       0.99      0.92      0.95       271
    
        accuracy                           0.98      1363
       macro avg       0.99      0.96      0.97      1363
    weighted avg       0.98      0.98      0.98      1363
    
    


```python

```


```python
from sklearn.metrics import roc_curve, roc_auc_score

fpr, tpr, thresholds = roc_curve(y_test, y_proba)
roc_auc = roc_auc_score(y_test, y_proba)

plt.figure(figsize=(7,5))
plt.plot(fpr, tpr, label=f"Random Forest (AUC = {roc_auc:.3f})")
plt.plot([0, 1], [0, 1], linestyle="--")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve – Best Model (Random Forest)")
plt.legend()
plt.show()

```


    
![png](output_44_0.png)
    



```python
# Extract feature names after preprocessing
feature_names = best_rf.named_steps["preprocessor"].get_feature_names_out()

# Extract feature importance from Random Forest
importances = best_rf.named_steps["model"].feature_importances_

# Create importance dataframe
fi_df = pd.DataFrame({
    "Feature": feature_names,
    "Importance": importances
}).sort_values(by="Importance", ascending=False)

# Plot top 10 features
top10 = fi_df.head(10)

plt.figure(figsize=(8,5))
plt.barh(top10["Feature"], top10["Importance"])
plt.gca().invert_yaxis()
plt.xlabel("Importance Score")
plt.title("Top 10 Drivers of Customer Churn – Random Forest")
plt.show()

```


    
![png](output_45_0.png)
    



```python

```


```python
# THRESHOLD TUNING using Default threshold = 0.5

thresholds = np.arange(0.1, 0.9, 0.05)
f1_scores = []

for t in thresholds:
    y_thresh_pred = (y_proba >= t).astype(int)
    f1_scores.append(f1_score(y_test, y_thresh_pred))

best_threshold = thresholds[np.argmax(f1_scores)]

print("Optimal Threshold:", best_threshold)
print("Best F1 at Threshold:", max(f1_scores))


```

    Optimal Threshold: 0.30000000000000004
    Best F1 at Threshold: 0.9762340036563071
    


```python

```


```python

```
